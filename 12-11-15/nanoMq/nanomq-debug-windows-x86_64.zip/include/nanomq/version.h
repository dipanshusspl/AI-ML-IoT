#define NANO_VER_MAJOR 0
#define NANO_VER_MINOR 24
#define NANO_VER_PATCH 5
#define NANO_VER_ID_SHORT "8"
